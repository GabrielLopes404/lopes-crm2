import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { canManageUsers, getRoleName, isUnauthorizedError } from "@/lib/authUtils";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Search,
  UserCog,
  Mail,
  Calendar,
  Shield,
  CheckCircle2,
  XCircle,
  Users,
} from "lucide-react";

import type { User, UserRole } from "@shared/schema";

const roleColors: Record<UserRole, { bg: string; text: string; border: string }> = {
  admin: {
    bg: "bg-purple-500/20",
    text: "text-purple-400",
    border: "border-purple-500/30",
  },
  gerente: {
    bg: "bg-blue-500/20",
    text: "text-blue-400",
    border: "border-blue-500/30",
  },
  funcionario: {
    bg: "bg-gray-500/20",
    text: "text-gray-400",
    border: "border-gray-500/30",
  },
};

export default function UsersPage() {
  const { user: currentUser } = useAuth();
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");
  const [roleFilter, setRoleFilter] = useState<string>("all");

  const isAdmin = canManageUsers(currentUser?.role);

  const { data: users, isLoading } = useQuery<User[]>({
    queryKey: ["/api/users"],
    enabled: isAdmin,
  });

  const updateRoleMutation = useMutation({
    mutationFn: async ({ id, role }: { id: string; role: UserRole }) => {
      return apiRequest("PATCH", `/api/users/${id}/role`, { role });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      toast({
        title: "Cargo atualizado",
        description: "O cargo do usuário foi atualizado com sucesso.",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Não autorizado",
          description: "Você será redirecionado para login...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Erro",
        description: "Não foi possível atualizar o cargo do usuário.",
        variant: "destructive",
      });
    },
  });

  const filteredUsers = users?.filter((user) => {
    const matchesSearch =
      user.firstName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.lastName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.email?.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesRole = roleFilter === "all" || user.role === roleFilter;

    return matchesSearch && matchesRole;
  });

  const getInitials = (firstName?: string | null, lastName?: string | null) => {
    const first = firstName?.charAt(0) || "";
    const last = lastName?.charAt(0) || "";
    return (first + last).toUpperCase() || "U";
  };

  const handleRoleChange = (userId: string, newRole: UserRole) => {
    if (userId === currentUser?.id) {
      toast({
        title: "Ação não permitida",
        description: "Você não pode alterar seu próprio cargo.",
        variant: "destructive",
      });
      return;
    }
    updateRoleMutation.mutate({ id: userId, role: newRole });
  };

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-[#0a0a0f] flex items-center justify-center p-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          className="text-center"
        >
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-red-500/20 border border-red-500/30 mb-4">
            <Shield className="h-8 w-8 text-red-400" />
          </div>
          <h1 className="text-2xl font-bold text-white mb-2">Acesso Restrito</h1>
          <p className="text-gray-400">
            Apenas administradores podem acessar esta página.
          </p>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0a0f] p-6 md:p-8 space-y-6">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_left,_var(--tw-gradient-stops))] from-purple-900/10 via-transparent to-transparent pointer-events-none" />

      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="relative"
      >
        <div className="flex items-center gap-3 mb-2">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-gradient-to-r from-purple-500/10 to-pink-500/10 border border-purple-500/20">
            <UserCog className="h-4 w-4 text-purple-400" />
            <span className="text-sm text-purple-300">Administração</span>
          </div>
        </div>
        <h1 className="text-3xl font-bold text-white">Gestão de Usuários</h1>
        <p className="text-gray-400 mt-1">
          Gerencie usuários e seus níveis de acesso
        </p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
        className="flex flex-col sm:flex-row gap-4 relative"
      >
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Buscar por nome ou email..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 bg-white/5 border-white/10 text-white placeholder:text-gray-500"
          />
        </div>
        <Select value={roleFilter} onValueChange={setRoleFilter}>
          <SelectTrigger className="w-full sm:w-[180px] bg-white/5 border-white/10 text-white">
            <SelectValue placeholder="Filtrar por cargo" />
          </SelectTrigger>
          <SelectContent className="bg-[#12121a] border-white/10">
            <SelectItem value="all" className="text-white hover:bg-white/10">
              Todos os cargos
            </SelectItem>
            <SelectItem value="admin" className="text-white hover:bg-white/10">
              Administrador
            </SelectItem>
            <SelectItem value="gerente" className="text-white hover:bg-white/10">
              Gerente
            </SelectItem>
            <SelectItem value="funcionario" className="text-white hover:bg-white/10">
              Funcionário
            </SelectItem>
          </SelectContent>
        </Select>
      </motion.div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="bg-[#12121a] border-white/10">
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <Skeleton className="h-12 w-12 rounded-full bg-white/10" />
                  <div className="flex-1 space-y-2">
                    <Skeleton className="h-5 w-32 bg-white/10" />
                    <Skeleton className="h-4 w-48 bg-white/10" />
                    <Skeleton className="h-6 w-20 bg-white/10" />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : filteredUsers?.length === 0 ? (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="flex flex-col items-center justify-center py-16"
        >
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-white/5 border border-white/10 mb-4">
            <Users className="h-8 w-8 text-gray-400" />
          </div>
          <h3 className="text-lg font-medium text-white mb-1">
            Nenhum usuário encontrado
          </h3>
          <p className="text-gray-400 text-sm">
            Tente ajustar os filtros de busca
          </p>
        </motion.div>
      ) : (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"
        >
          {filteredUsers?.map((user, index) => {
            const roleColor = roleColors[user.role];
            const isCurrentUser = user.id === currentUser?.id;

            return (
              <motion.div
                key={user.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
              >
                <Card className="bg-[#12121a] border-white/10 hover:border-white/20 transition-all duration-300 group">
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <Avatar className="h-12 w-12 ring-2 ring-white/10 group-hover:ring-purple-500/30 transition-all">
                        <AvatarImage
                          src={user.profileImageUrl || undefined}
                          alt={user.firstName || "User"}
                          className="object-cover"
                        />
                        <AvatarFallback className="bg-gradient-to-br from-purple-500 to-pink-500 text-white text-sm font-medium">
                          {getInitials(user.firstName, user.lastName)}
                        </AvatarFallback>
                      </Avatar>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <h3 className="font-semibold text-white truncate">
                            {user.firstName} {user.lastName}
                          </h3>
                          {isCurrentUser && (
                            <Badge
                              variant="outline"
                              className="text-xs bg-purple-500/10 text-purple-400 border-purple-500/30"
                            >
                              Você
                            </Badge>
                          )}
                        </div>

                        <div className="flex items-center gap-1.5 mt-1 text-sm text-gray-400">
                          <Mail className="h-3.5 w-3.5" />
                          <span className="truncate">{user.email || "—"}</span>
                        </div>

                        <div className="flex items-center gap-3 mt-3">
                          <div className="flex items-center gap-1.5">
                            {user.isActive ? (
                              <CheckCircle2 className="h-4 w-4 text-green-400" />
                            ) : (
                              <XCircle className="h-4 w-4 text-red-400" />
                            )}
                            <span
                              className={`text-xs ${
                                user.isActive ? "text-green-400" : "text-red-400"
                              }`}
                            >
                              {user.isActive ? "Ativo" : "Inativo"}
                            </span>
                          </div>

                          {user.createdAt && (
                            <div className="flex items-center gap-1.5 text-xs text-gray-500">
                              <Calendar className="h-3.5 w-3.5" />
                              <span>
                                {format(new Date(user.createdAt), "dd/MM/yyyy", {
                                  locale: ptBR,
                                })}
                              </span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="mt-4 pt-4 border-t border-white/10">
                      <div className="flex items-center justify-between gap-4">
                        <span className="text-sm text-gray-400">Cargo:</span>
                        {isCurrentUser ? (
                          <Badge
                            className={`${roleColor.bg} ${roleColor.text} ${roleColor.border} border`}
                          >
                            {getRoleName(user.role)}
                          </Badge>
                        ) : (
                          <Select
                            value={user.role}
                            onValueChange={(value) =>
                              handleRoleChange(user.id, value as UserRole)
                            }
                            disabled={updateRoleMutation.isPending}
                          >
                            <SelectTrigger
                              className={`w-[140px] h-8 text-sm ${roleColor.bg} ${roleColor.border} border ${roleColor.text}`}
                            >
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent className="bg-[#12121a] border-white/10">
                              <SelectItem
                                value="admin"
                                className="text-purple-400 hover:bg-white/10"
                              >
                                Administrador
                              </SelectItem>
                              <SelectItem
                                value="gerente"
                                className="text-blue-400 hover:bg-white/10"
                              >
                                Gerente
                              </SelectItem>
                              <SelectItem
                                value="funcionario"
                                className="text-gray-400 hover:bg-white/10"
                              >
                                Funcionário
                              </SelectItem>
                            </SelectContent>
                          </Select>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </motion.div>
      )}

      {filteredUsers && filteredUsers.length > 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="flex justify-center pt-4"
        >
          <p className="text-sm text-gray-500">
            Exibindo {filteredUsers.length} de {users?.length || 0} usuários
          </p>
        </motion.div>
      )}
    </div>
  );
}
