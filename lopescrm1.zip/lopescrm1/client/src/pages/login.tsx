import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { 
  LogIn, 
  Palette, 
  Globe, 
  BarChart3, 
  Shield, 
  Users, 
  FolderKanban,
  Sparkles,
  Target,
  TrendingUp,
  CheckCircle2,
  Lock
} from "lucide-react";
import logoImage from "@assets/logo.png";

export default function Login() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  const stats = [
    { value: "350+", label: "Projetos Entregues" },
    { value: "98%", label: "Satisfação" },
    { value: "24h", label: "Suporte" },
  ];

  const features = [
    { icon: Users, label: "Gestão de Clientes", color: "from-blue-500 to-cyan-500" },
    { icon: FolderKanban, label: "Controle de Projetos", color: "from-purple-500 to-pink-500" },
    { icon: Target, label: "Metas e Objetivos", color: "from-orange-500 to-amber-500" },
    { icon: TrendingUp, label: "Relatórios Detalhados", color: "from-green-500 to-emerald-500" },
  ];

  return (
    <div className="min-h-screen bg-[#0a0a0f] relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-purple-900/20 via-transparent to-transparent" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_right,_var(--tw-gradient-stops))] from-blue-900/10 via-transparent to-transparent" />
      
      <div className="absolute top-20 left-10 w-72 h-72 bg-purple-500/10 rounded-full blur-3xl animate-pulse" />
      <div className="absolute bottom-20 right-10 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
      <div className="absolute top-1/2 left-1/2 w-64 h-64 bg-pink-500/5 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '2s' }} />
      
      <div className="relative z-10 flex min-h-screen">
        <div className="hidden lg:flex lg:w-1/2 xl:w-3/5 flex-col justify-center px-12 xl:px-20">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-purple-500/10 to-blue-500/10 border border-purple-500/20 mb-8">
              <Sparkles className="h-4 w-4 text-purple-400" />
              <span className="text-sm text-purple-300">Sistema Profissional de Gestão</span>
            </div>
            
            <h1 className="text-4xl xl:text-6xl font-bold text-white leading-tight mb-6">
              Gerencie sua{" "}
              <span className="bg-gradient-to-r from-purple-400 via-pink-400 to-blue-400 bg-clip-text text-transparent">
                agência
              </span>
              <br />
              de forma inteligente
            </h1>
            
            <p className="text-lg text-gray-400 mb-10 max-w-xl">
              Controle seus clientes, projetos e tarefas em um único lugar. 
              Aumente sua produtividade e entregue resultados extraordinários.
            </p>

            <div className="grid grid-cols-3 gap-6 mb-12">
              {stats.map((stat, index) => (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.2 + index * 0.1 }}
                  className="text-center"
                >
                  <div className="text-3xl xl:text-4xl font-bold bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
                    {stat.value}
                  </div>
                  <div className="text-sm text-gray-500 mt-1">{stat.label}</div>
                </motion.div>
              ))}
            </div>

            <div className="grid grid-cols-2 gap-4">
              {features.map((feature, index) => (
                <motion.div
                  key={feature.label}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.4 + index * 0.1 }}
                  className="flex items-center gap-3 p-4 rounded-xl bg-white/5 border border-white/10 backdrop-blur-sm hover:bg-white/10 transition-all duration-300 group"
                >
                  <div className={`p-2 rounded-lg bg-gradient-to-r ${feature.color}`}>
                    <feature.icon className="h-5 w-5 text-white" />
                  </div>
                  <span className="text-gray-300 group-hover:text-white transition-colors">
                    {feature.label}
                  </span>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>

        <div className="w-full lg:w-1/2 xl:w-2/5 flex items-center justify-center px-6 lg:px-12">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="w-full max-w-md"
          >
            <div className="relative">
              <div className="absolute -inset-1 bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 rounded-3xl blur opacity-20" />
              <div className="relative bg-[#12121a] border border-white/10 rounded-3xl p-8 lg:p-10 shadow-2xl">
                <div className="text-center mb-8">
                  <motion.div
                    initial={{ scale: 0.5 }}
                    animate={{ scale: 1 }}
                    transition={{ duration: 0.5, type: "spring" }}
                    className="inline-flex items-center justify-center h-24 w-24 rounded-2xl bg-black/50 shadow-lg shadow-purple-500/30 mb-6 p-2"
                  >
                    <img src={logoImage} alt="Lopes Agency" className="w-full h-full object-contain" />
                  </motion.div>
                  <h2 className="text-2xl font-bold text-white mb-2">Lopes Agency</h2>
                  <p className="text-gray-400">Sistema de Gestão de Clientes</p>
                </div>

                <div className="space-y-6">
                  <div className="p-4 rounded-xl bg-gradient-to-r from-purple-500/10 to-blue-500/10 border border-purple-500/20">
                    <div className="flex items-start gap-3">
                      <div className="p-2 rounded-lg bg-purple-500/20">
                        <Lock className="h-5 w-5 text-purple-400" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-white text-sm">Login Seguro</h3>
                        <p className="text-xs text-gray-400 mt-1">
                          Autenticação protegida com criptografia
                        </p>
                      </div>
                    </div>
                  </div>

                  <Button 
                    onClick={handleLogin} 
                    className="w-full h-14 text-base font-semibold gap-3 bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 hover:from-purple-500 hover:via-pink-500 hover:to-blue-500 border-0 shadow-lg shadow-purple-500/25 transition-all duration-300 hover:shadow-purple-500/40 hover:scale-[1.02]"
                    data-testid="button-login"
                  >
                    <LogIn className="h-5 w-5" />
                    Acessar Sistema
                  </Button>

                  <div className="grid grid-cols-3 gap-3 pt-6 border-t border-white/10">
                    <div className="text-center p-3 rounded-xl bg-white/5 hover:bg-white/10 transition-colors group cursor-default">
                      <div className="h-10 w-10 mx-auto rounded-xl bg-gradient-to-br from-blue-500/20 to-cyan-500/20 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
                        <Palette className="h-5 w-5 text-blue-400" />
                      </div>
                      <span className="text-xs text-gray-400">Design</span>
                    </div>
                    <div className="text-center p-3 rounded-xl bg-white/5 hover:bg-white/10 transition-colors group cursor-default">
                      <div className="h-10 w-10 mx-auto rounded-xl bg-gradient-to-br from-green-500/20 to-emerald-500/20 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
                        <Globe className="h-5 w-5 text-green-400" />
                      </div>
                      <span className="text-xs text-gray-400">Sites</span>
                    </div>
                    <div className="text-center p-3 rounded-xl bg-white/5 hover:bg-white/10 transition-colors group cursor-default">
                      <div className="h-10 w-10 mx-auto rounded-xl bg-gradient-to-br from-purple-500/20 to-pink-500/20 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
                        <BarChart3 className="h-5 w-5 text-purple-400" />
                      </div>
                      <span className="text-xs text-gray-400">Tráfego</span>
                    </div>
                  </div>
                </div>

                <div className="mt-8 pt-6 border-t border-white/10">
                  <div className="flex items-center justify-center gap-2 text-sm text-gray-500">
                    <CheckCircle2 className="h-4 w-4 text-green-500" />
                    <span>Acesso exclusivo para colaboradores</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="lg:hidden mt-10">
              <div className="grid grid-cols-3 gap-4 text-center">
                {stats.map((stat) => (
                  <div key={stat.label}>
                    <div className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
                      {stat.value}
                    </div>
                    <div className="text-xs text-gray-500">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
