import { useLocation, Link } from "wouter";
import { motion } from "framer-motion";
import {
  LayoutDashboard,
  Users,
  FolderKanban,
  CheckSquare,
  BarChart3,
  Target,
  LogOut,
  Sparkles,
  UserCog,
} from "lucide-react";
import logoImage from "@assets/logo.png";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
} from "@/components/ui/sidebar";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/useAuth";
import { getRoleName, getRoleBadgeColor, canViewFinancials, canManageUsers } from "@/lib/authUtils";

const mainNavItems = [
  {
    title: "Dashboard",
    url: "/",
    icon: LayoutDashboard,
    gradient: "from-purple-500 to-pink-500",
  },
  {
    title: "Clientes",
    url: "/clientes",
    icon: Users,
    gradient: "from-blue-500 to-cyan-500",
  },
  {
    title: "Projetos",
    url: "/projetos",
    icon: FolderKanban,
    gradient: "from-orange-500 to-amber-500",
  },
  {
    title: "Tarefas",
    url: "/tarefas",
    icon: CheckSquare,
    gradient: "from-green-500 to-emerald-500",
  },
];

const financeNavItems = [
  {
    title: "Relatórios",
    url: "/relatorios",
    icon: BarChart3,
    gradient: "from-indigo-500 to-purple-500",
  },
  {
    title: "Metas",
    url: "/metas",
    icon: Target,
    gradient: "from-rose-500 to-pink-500",
  },
];

const adminNavItems = [
  {
    title: "Usuários",
    url: "/usuarios",
    icon: UserCog,
    gradient: "from-purple-500 to-violet-500",
  },
];

export function AppSidebar() {
  const [location] = useLocation();
  const { user } = useAuth();

  const getInitials = (firstName?: string | null, lastName?: string | null) => {
    const first = firstName?.charAt(0) || "";
    const last = lastName?.charAt(0) || "";
    return (first + last).toUpperCase() || "U";
  };

  const showFinanceSection = canViewFinancials(user?.role);
  const showAdminSection = canManageUsers(user?.role);

  return (
    <Sidebar className="bg-[#0d0d14] border-r border-white/10">
      <SidebarHeader className="border-b border-white/10 p-4">
        <div className="flex items-center gap-3">
          <motion.div
            initial={{ scale: 0.8 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.3 }}
            className="flex h-11 w-11 items-center justify-center rounded-xl bg-black/50 shadow-lg shadow-purple-500/30 p-1"
          >
            <img src={logoImage} alt="Lopes Agency" className="w-full h-full object-contain" />
          </motion.div>
          <div className="flex flex-col">
            <span className="font-semibold text-white">Lopes Agency</span>
            <div className="flex items-center gap-1.5">
              <Sparkles className="h-3 w-3 text-purple-400" />
              <span className="text-xs text-gray-400">CRM Pro</span>
            </div>
          </div>
        </div>
      </SidebarHeader>
      
      <SidebarContent className="px-2 py-4">
        <SidebarGroup>
          <SidebarGroupLabel className="text-xs font-semibold text-gray-500 uppercase tracking-wider px-3 mb-2">
            Principal
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {mainNavItems.map((item, index) => {
                const isActive = location === item.url;
                return (
                  <SidebarMenuItem key={item.title}>
                    <motion.div
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.3, delay: index * 0.05 }}
                    >
                      <SidebarMenuButton
                        asChild
                        isActive={isActive}
                        data-testid={`nav-${item.title.toLowerCase()}`}
                        className={`relative group rounded-xl transition-all duration-300 ${
                          isActive 
                            ? 'bg-white/10 text-white' 
                            : 'text-gray-400 hover:text-white hover:bg-white/5'
                        }`}
                      >
                        <Link href={item.url} className="flex items-center gap-3 px-3 py-2.5">
                          <div className={`p-1.5 rounded-lg transition-all duration-300 ${
                            isActive 
                              ? `bg-gradient-to-r ${item.gradient}` 
                              : 'bg-white/10 group-hover:bg-white/20'
                          }`}>
                            <item.icon className="h-4 w-4 text-white" />
                          </div>
                          <span className="font-medium">{item.title}</span>
                          {isActive && (
                            <motion.div
                              layoutId="activeIndicator"
                              className="absolute right-3 w-1.5 h-1.5 rounded-full bg-gradient-to-r from-purple-400 to-pink-400"
                            />
                          )}
                        </Link>
                      </SidebarMenuButton>
                    </motion.div>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {showFinanceSection && (
          <SidebarGroup className="mt-6">
            <SidebarGroupLabel className="text-xs font-semibold text-gray-500 uppercase tracking-wider px-3 mb-2">
              Financeiro
            </SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {financeNavItems.map((item, index) => {
                  const isActive = location === item.url;
                  return (
                    <SidebarMenuItem key={item.title}>
                      <motion.div
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.3, delay: (mainNavItems.length + index) * 0.05 }}
                      >
                        <SidebarMenuButton
                          asChild
                          isActive={isActive}
                          data-testid={`nav-${item.title.toLowerCase()}`}
                          className={`relative group rounded-xl transition-all duration-300 ${
                            isActive 
                              ? 'bg-white/10 text-white' 
                              : 'text-gray-400 hover:text-white hover:bg-white/5'
                          }`}
                        >
                          <Link href={item.url} className="flex items-center gap-3 px-3 py-2.5">
                            <div className={`p-1.5 rounded-lg transition-all duration-300 ${
                              isActive 
                                ? `bg-gradient-to-r ${item.gradient}` 
                                : 'bg-white/10 group-hover:bg-white/20'
                            }`}>
                              <item.icon className="h-4 w-4 text-white" />
                            </div>
                            <span className="font-medium">{item.title}</span>
                            {isActive && (
                              <motion.div
                                layoutId="activeIndicatorFinance"
                                className="absolute right-3 w-1.5 h-1.5 rounded-full bg-gradient-to-r from-purple-400 to-pink-400"
                              />
                            )}
                          </Link>
                        </SidebarMenuButton>
                      </motion.div>
                    </SidebarMenuItem>
                  );
                })}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}

        {showAdminSection && (
          <SidebarGroup className="mt-6">
            <SidebarGroupLabel className="text-xs font-semibold text-gray-500 uppercase tracking-wider px-3 mb-2">
              Administração
            </SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {adminNavItems.map((item, index) => {
                  const isActive = location === item.url;
                  return (
                    <SidebarMenuItem key={item.title}>
                      <motion.div
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.3, delay: (mainNavItems.length + financeNavItems.length + index) * 0.05 }}
                      >
                        <SidebarMenuButton
                          asChild
                          isActive={isActive}
                          data-testid={`nav-${item.title.toLowerCase()}`}
                          className={`relative group rounded-xl transition-all duration-300 ${
                            isActive 
                              ? 'bg-white/10 text-white' 
                              : 'text-gray-400 hover:text-white hover:bg-white/5'
                          }`}
                        >
                          <Link href={item.url} className="flex items-center gap-3 px-3 py-2.5">
                            <div className={`p-1.5 rounded-lg transition-all duration-300 ${
                              isActive 
                                ? `bg-gradient-to-r ${item.gradient}` 
                                : 'bg-white/10 group-hover:bg-white/20'
                            }`}>
                              <item.icon className="h-4 w-4 text-white" />
                            </div>
                            <span className="font-medium">{item.title}</span>
                            {isActive && (
                              <motion.div
                                layoutId="activeIndicatorAdmin"
                                className="absolute right-3 w-1.5 h-1.5 rounded-full bg-gradient-to-r from-purple-400 to-pink-400"
                              />
                            )}
                          </Link>
                        </SidebarMenuButton>
                      </motion.div>
                    </SidebarMenuItem>
                  );
                })}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}
      </SidebarContent>

      <SidebarFooter className="border-t border-white/10 p-4">
        <div className="flex items-center gap-3 p-3 rounded-xl bg-white/5 border border-white/10">
          <Avatar className="h-10 w-10 ring-2 ring-purple-500/30">
            <AvatarImage 
              src={user?.profileImageUrl || undefined} 
              alt={user?.firstName || "User"} 
              className="object-cover"
            />
            <AvatarFallback className="bg-gradient-to-br from-purple-500 to-pink-500 text-white text-sm font-medium">
              {getInitials(user?.firstName, user?.lastName)}
            </AvatarFallback>
          </Avatar>
          <div className="flex flex-col flex-1 min-w-0">
            <span className="font-medium text-sm text-white truncate">
              {user?.firstName} {user?.lastName}
            </span>
            <Badge 
              className={`text-xs w-fit mt-0.5 border ${
                user?.role === 'admin' 
                  ? 'bg-purple-500/20 text-purple-400 border-purple-500/30' 
                  : user?.role === 'gerente'
                  ? 'bg-blue-500/20 text-blue-400 border-blue-500/30'
                  : 'bg-gray-500/20 text-gray-400 border-gray-500/30'
              }`}
            >
              {getRoleName(user?.role)}
            </Badge>
          </div>
          <a
            href="/api/logout"
            className="p-2.5 rounded-xl bg-white/5 hover:bg-red-500/20 text-gray-400 hover:text-red-400 transition-all duration-300 border border-white/10 hover:border-red-500/30"
            data-testid="button-logout"
            title="Sair"
          >
            <LogOut className="h-4 w-4" />
          </a>
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
